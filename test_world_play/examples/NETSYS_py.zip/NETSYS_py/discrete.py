import numpy as np

class Discrete(object):
    def __init__(self, n):
        self.n = n
